// standard headers
#include <cstdio>
#include <iostream>
#include <cmath>

// my headers
#include "ODE_solver.h"
#include "forward_euler.h"
#include "backward_euler.h"
#include "functions_bank.h"
